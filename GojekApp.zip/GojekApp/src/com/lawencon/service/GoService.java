package com.lawencon.service;

import com.lawencon.model.Drivers;

public interface GoService {

	Drivers getDriver();
}
