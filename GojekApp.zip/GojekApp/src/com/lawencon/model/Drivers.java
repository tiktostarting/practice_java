package com.lawencon.model;

public class Drivers {

	private String nama;
	private String platNo;

	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public void setPlatNo(String platNo) {
		this.platNo = platNo;
	}
	
	public String getNama() {
		return this.nama;
	}
	
	public String getPlatNo() {
		return this.platNo;
	}
}
