package com.lawencon.constant;

public enum ServiceType {

	GORIDE, GOSEND, GOFOOD, GOPULSA
}
