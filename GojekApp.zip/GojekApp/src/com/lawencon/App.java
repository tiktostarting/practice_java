package com.lawencon;

import com.lawencon.view.AppView;

public class App {

	public static void main(String[] args) {
		AppView appView = new AppView();
		appView.show();
	}
}
