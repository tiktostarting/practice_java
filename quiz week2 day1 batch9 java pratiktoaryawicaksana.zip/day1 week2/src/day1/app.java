package day1;

import java.util.Scanner;

public class app {
	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		// scan object yang berasal dari class Scanner
		
		// ketika error dijalankan dinamakan runtime Exception
		// ketika error dijalankan dinamakn autodetect error
		
		//app App = new app();
		
		//Anonimous adalah deklarasi dan 
		//Overide adalah implementasi dan 
		
		
	}
}
