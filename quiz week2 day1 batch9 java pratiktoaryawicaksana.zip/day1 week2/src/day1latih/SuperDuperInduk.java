package day1latih;

public class SuperDuperInduk {
	public void minum() {
		System.out.println("minum teh");
	}
}
