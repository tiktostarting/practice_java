package day1latih;

public class Induk {
	public void minum() {
		System.out.println("minum air");
	}
	//setiap method yang method yang abstrak wajib di override
	
	public void makan() {
		System.out.println("");
	}
	
}
