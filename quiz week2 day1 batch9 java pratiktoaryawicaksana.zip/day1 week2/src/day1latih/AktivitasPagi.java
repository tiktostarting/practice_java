package day1latih;

public interface AktivitasPagi {
	
	//abstrack void lari();
	void lari();
	
}
