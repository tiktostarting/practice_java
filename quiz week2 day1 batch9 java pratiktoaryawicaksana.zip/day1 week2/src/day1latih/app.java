package day1latih;

public class app {
	public static void main(String[] args) {
		Anak1 anak = new Anak1();
		anak.makan();
	}
}
