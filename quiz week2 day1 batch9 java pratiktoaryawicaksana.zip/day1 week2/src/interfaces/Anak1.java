package interfaces;

public class Anak1 extends Induk implements AktivitasPago {
	
	@Override
	public void senam() {
		
	}
	
	@Override
	public void lari() {
		
	}
}
