package interfaces;

public class Induk {
	public void senam() {
		
	}
}
