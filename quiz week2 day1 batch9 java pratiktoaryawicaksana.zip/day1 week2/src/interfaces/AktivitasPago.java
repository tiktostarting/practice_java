package interfaces;

public interface AktivitasPago {
	void lari();
}
