package interfaces;

public class app {
	public static void main(String[] args) {
		
		//anak tipe induk
		//induk bukan anak
		//anak tipe inteface
		
		// 
		
		Induk induk = new Induk();
		Induk induk2 = new Anak1();
		AktivitasPago induk3 = new Anak1();
		
		
	}
}
