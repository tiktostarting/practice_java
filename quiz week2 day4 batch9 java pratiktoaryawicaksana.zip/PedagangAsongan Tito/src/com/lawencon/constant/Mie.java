package com.lawencon.constant;

public enum Mie {
	INDOMIE, MIESEDAP, SARIMI;
}
