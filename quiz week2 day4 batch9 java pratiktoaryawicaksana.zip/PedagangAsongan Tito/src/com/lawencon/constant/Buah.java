package com.lawencon.constant;

public enum Buah {
	DURIAN, APEL, MANGGA, NANAS;
}
