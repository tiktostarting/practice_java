package com.lawencon.constant;

public enum Sayuran {
	BAYAM, BROKOLI, KOL;
}
