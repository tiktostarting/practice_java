package com.lawencon.constant;

public enum AirMineral {
	AQUA, DANONE, LEMINERAL;
}
