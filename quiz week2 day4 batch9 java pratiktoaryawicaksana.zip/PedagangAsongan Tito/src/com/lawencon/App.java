package com.lawencon;
import com.lawencon.view.AppMenuView;

public class App {
	public static void main(String[] args) {
		AppMenuView main = new AppMenuView();
		main.show();
		System.exit(0);
	}
}
