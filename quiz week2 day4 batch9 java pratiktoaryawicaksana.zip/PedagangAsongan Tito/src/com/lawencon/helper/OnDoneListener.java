package com.lawencon.helper;

public interface OnDoneListener {
	void done();
}
