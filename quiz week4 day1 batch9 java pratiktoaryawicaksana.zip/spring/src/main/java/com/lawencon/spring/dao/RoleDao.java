package com.lawencon.spring.dao;

import com.lawencon.spring.model.Role;

public interface RoleDao {
	void insert(Role data);
	void update(Role data);
	void delete(Long id);
	Role getById(Integer id);
	Role getByName(String name);
}
