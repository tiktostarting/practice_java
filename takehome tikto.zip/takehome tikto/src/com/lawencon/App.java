package com.lawencon;

import com.lawencon.view.LoginView;

public class App {
	public static void main(String[] args) {
		LoginView login = new LoginView();
		login.show();
		System.exit(0);
	}
}
