package com.lawencon.service;

public interface BeliService {

}
