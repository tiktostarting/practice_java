package com.lawencon.service;

import java.util.ArrayList;
import java.util.List;
import com.lawencon.model.Barang;

public class StokServiceImpl implements StokService {
	
	protected List<Barang> item = new ArrayList<Barang>();
	
	public void tambah() {
		Barang terbaru = new Barang();
		terbaru.setHarga(0);
		terbaru.setItem("");
		terbaru.setJenis("");
		terbaru.setStok(0);
		item.add(terbaru);
	}
	
	public void ubah() {
		Barang terkini = new Barang();
		terkini.setHarga(0);
		terkini.setItem("");
		terkini.setJenis("");
		terkini.setStok(0);
		item.add(index - 1, terkini);
	}
	
	public void hapus() {
		Barang terbaru = new Barang();
		terbaru.setHarga(0);
		terbaru.setItem("");
		terbaru.setJenis("");
		terbaru.setStok(0);
		item.remove(index - 1, terkini);
	}
}
