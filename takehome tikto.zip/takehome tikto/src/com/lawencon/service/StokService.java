package com.lawencon.service;

public interface StokService {
	public void tambah();
	public void ubah();
	public void hapus();
}
