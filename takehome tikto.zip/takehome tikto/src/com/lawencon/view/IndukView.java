package com.lawencon.view;

import java.util.ArrayList;
import java.util.List;
import com.lawencon.model.Barang;

public class IndukView {
	protected List<Barang> item = new ArrayList<Barang>();
	
	public void listJenisItem() {
		for(Barang i : item) {
			System.out.println(i.getJenis());
		}
	}
	
	public void listSemuaItem() {
		for(Barang i : item) {
			System.out.println( i.getJenis()+" "+i.getItem()+" "+i.getHarga()+ " " + i.getStok() );
		}
	}
	
	public void tambahItem(String user) {
		
	}
	
	public void hapusItem(String user) {
		
	}
	
	public void ubahItem(String user) {
		
	}
	

	
	public void logIn() {
		
	}
	
	public void keluar() {
		System.exit(0);
	}
}
