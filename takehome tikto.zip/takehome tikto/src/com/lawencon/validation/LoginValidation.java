package com.lawencon.validation;

public interface LoginValidation {
	public String tryLogin(String username, String password);
	public void routesPedagang();
	public void routesPelanggan();
}
