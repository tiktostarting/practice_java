package com.lawencon.model;

public class Drivers {
	private String nama;
	private String platNo;
	private String noHp;
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public void setPlatNo(String platNo) {
		this.platNo = platNo;
	}
	
	public void setNoHp(String NoHp) {
		this.noHp = NoHp;
	}
	
	public String getNama() {
		return this.nama;
	}

	public String getPlatNo() {
		return this.platNo;
	}
	
	public String getNoHP() {
		return this.noHp;
	}
}
