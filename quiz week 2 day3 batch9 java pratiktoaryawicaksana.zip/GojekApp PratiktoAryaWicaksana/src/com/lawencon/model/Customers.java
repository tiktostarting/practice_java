package com.lawencon.model;

public class Customers {
	private String nama;
	private String alamat;
	private String noHp;
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}
	
	public void setNoHP(String noHp) {
		this.noHp = noHp;
	}
	
	public String getNama() {
		return this.nama;
	}
	
	public String getAlamat() {
		return this.alamat;
	}
	
	public String getNoHp() {
		return this.noHp;
	}
}
