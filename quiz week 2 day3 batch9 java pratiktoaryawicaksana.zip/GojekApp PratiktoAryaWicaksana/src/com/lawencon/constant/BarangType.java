package com.lawencon.constant;

public enum BarangType {

	LAINLAIN, ELEKTRONIK, PECAHBELAH, DOKUMEN;

}
