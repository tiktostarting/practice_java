package com.lawencon;

import com.lawencon.view.AppView;

public class App {
	public static void main(String[] args) {
		AppView app = new AppView();
		app.show();
		System.exit(0);
	}
}
